import React from "react";

function Home() {
  return (
    <div>
      <h1>Welcome..!</h1>
      <br />
      <h3>
        You are not loggen In
        <br /> 
        Please LogIn yourself.
      </h3>
    </div>
  );
}

export default Home;
